TRAMAZY BARBER - Android APK Builder

IMPORTANT:
This is an Android source project, not a prebuilt APK. GitHub Actions can build the APK for you.

How to use:
1. Upload the CONTENTS of this folder into the root of your GitHub repository (keep .github/workflows/build-apk.yml).
2. Open your repository on GitHub.
3. Tap Actions.
4. Select "Build Tramazy Barber APK".
5. Tap "Run workflow" if it did not start automatically.
6. When it finishes successfully, open the run and download the artifact named "Tramazy-Barber-debug-APK".
7. Extract the downloaded artifact ZIP to get app-debug.apk, then open it on your Android phone to install.

This creates a debug APK for testing, not a Play Store release bundle.
